describe('{$ doc.id $}', function() {

it('should init', function() {
  browser.get('{$ doc.url $}');
});

{$ doc.contents $}

});
