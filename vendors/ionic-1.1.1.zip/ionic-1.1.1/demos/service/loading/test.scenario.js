---
name: complete
component: $ionicLoading
---
